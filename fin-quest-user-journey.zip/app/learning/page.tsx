'use client';

import React, { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { StudentLearningView } from '@/components/learning/StudentLearningView';
import { TeacherLearningView } from '@/components/learning/TeacherLearningView';

export default function LearningPage() {
  const router = useRouter();
  const { isAuthenticated, user, isLoading } = useAuth();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      router.push('/login');
    }
  }, [isAuthenticated, isLoading, router]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <p className="text-muted-foreground">Loading learning resources...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  // Route to appropriate learning view based on user role
  if (user?.role === 'teacher') {
    return <TeacherLearningView />;
  }

  return <StudentLearningView />;
}
