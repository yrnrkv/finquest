'use client';

import React from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { mockAssignments, mockStudentAssignments, mockModules } from '@/lib/mock-data';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { CheckCircle, ArrowLeft } from 'lucide-react';

export default function GradeResultPage() {
  const { user } = useAuth();
  const router = useRouter();
  const params = useParams();
  const assignmentId = params.assignmentId as string;

  if (!user || user.role !== 'student') {
    return null;
  }

  const assignment = mockAssignments.find(a => a.id === assignmentId);
  const submission = mockStudentAssignments.find(
    sa => sa.assignmentId === assignmentId && sa.studentId === user.id
  );
  const module = assignment ? mockModules.find(m => m.id === assignment.moduleId) : null;

  if (!assignment || !submission || submission.status !== 'graded') {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-3xl mx-auto">
          <Button
            variant="ghost"
            onClick={() => router.push('/student/assignments')}
            className="mb-6"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Assignments
          </Button>
          <Card className="bg-card border border-border">
            <CardContent className="pt-12 pb-12 text-center">
              <p className="text-muted-foreground mb-4">Grade not yet available</p>
              <Button onClick={() => router.push('/student/assignments')}>
                Return to Assignments
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const scorePercentage = submission.bestScore || 0;
  const getScoreCategory = () => {
    if (scorePercentage >= 85) return { label: 'Excellent', color: 'text-accent bg-accent/10' };
    if (scorePercentage >= 70) return { label: 'Good', color: 'text-secondary bg-secondary/10' };
    if (scorePercentage >= 50) return { label: 'Satisfactory', color: 'text-primary bg-primary/10' };
    return { label: 'Needs Improvement', color: 'text-destructive bg-destructive/10' };
  };

  const scoreCategory = getScoreCategory();
  const pointsEarned = Math.round((scorePercentage / 100) * assignment.totalPoints);

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-card p-6">
      <div className="max-w-3xl mx-auto">
        {/* Back Button */}
        <Button
          variant="ghost"
          onClick={() => router.push('/student/assignments')}
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Assignments
        </Button>

        {/* Grade Card */}
        <Card className="bg-gradient-to-br from-card to-card/50 border border-border/50 overflow-hidden">
          <CardHeader className="text-center pt-12 bg-gradient-to-r from-primary/10 to-secondary/10">
            <div className="flex justify-center mb-4">
              <CheckCircle className="w-12 h-12 text-accent" />
            </div>
            <CardTitle className="text-3xl mb-2">{assignment.title}</CardTitle>
            <CardDescription>{module?.name}</CardDescription>
          </CardHeader>

          <CardContent className="space-y-8 pt-12">
            {/* Score Display */}
            <div className="bg-background/50 p-8 rounded-lg border border-border/50 text-center space-y-4">
              <p className="text-muted-foreground text-sm">YOUR SCORE</p>
              <div className="flex items-baseline justify-center gap-3">
                <span className={`text-6xl font-bold ${scoreCategory.color.split(' ')[0]}`}>
                  {scorePercentage}
                </span>
                <span className="text-2xl text-muted-foreground">%</span>
              </div>
              <Progress value={scorePercentage} className="h-3" />
              <Badge className={`${scoreCategory.color}`}>
                {scoreCategory.label}
              </Badge>
            </div>

            {/* Points Information */}
            <div className="grid grid-cols-2 gap-6">
              <div className="bg-secondary/10 p-6 rounded-lg border border-secondary/20">
                <p className="text-sm text-muted-foreground mb-2">Points Earned</p>
                <p className="text-3xl font-bold text-secondary">{pointsEarned}</p>
                <p className="text-xs text-muted-foreground mt-1">out of {assignment.totalPoints}</p>
              </div>
              <div className="bg-primary/10 p-6 rounded-lg border border-primary/20">
                <p className="text-sm text-muted-foreground mb-2">Quest Attempts</p>
                <p className="text-3xl font-bold text-primary">{submission.questAttempts}</p>
                <p className="text-xs text-muted-foreground mt-1">attempts completed</p>
              </div>
            </div>

            {/* Submission Details */}
            <div className="space-y-3 bg-background/50 p-6 rounded-lg border border-border/50">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Submitted:</span>
                <span className="text-foreground font-medium">
                  {submission.submittedAt ? new Date(submission.submittedAt).toLocaleDateString() : 'N/A'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Graded:</span>
                <span className="text-foreground font-medium">
                  {submission.gradedAt ? new Date(submission.gradedAt).toLocaleDateString() : 'N/A'}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Due Date:</span>
                <span className="text-foreground font-medium">
                  {new Date(assignment.dueDate).toLocaleDateString()}
                </span>
              </div>
            </div>

            {/* Feedback Section */}
            <div className="bg-accent/10 border border-accent/20 p-6 rounded-lg space-y-3">
              <h4 className="font-semibold text-foreground">Teacher Feedback</h4>
              <p className="text-muted-foreground">
                Great work on completing this assignment! Your understanding of the concepts is solid. Consider reviewing the areas marked in red for additional practice.
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4 pt-4">
              <Button
                onClick={() => router.push('/student/assignments')}
                className="flex-1 bg-primary hover:bg-primary/90 text-primary-foreground py-6"
              >
                Back to Assignments
              </Button>
              <Button
                onClick={() => router.push('/dashboard')}
                variant="outline"
                className="flex-1 py-6"
              >
                Return to Dashboard
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
