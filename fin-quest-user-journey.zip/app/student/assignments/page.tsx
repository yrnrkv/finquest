'use client';

import { useAuth } from '@/lib/auth-context';
import StudentAssignmentsView from '@/components/student/StudentAssignmentsView';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function StudentAssignmentsPage() {
  const { user } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!user || user.role !== 'student') {
      router.push('/login');
    }
  }, [user, router]);

  if (!user || user.role !== 'student') {
    return null;
  }

  return <StudentAssignmentsView />;
}
