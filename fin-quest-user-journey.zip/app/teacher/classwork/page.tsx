'use client';

import { useAuth } from '@/lib/auth-context';
import ClassworkView from '@/components/teacher/ClassworkView';
import { useRouter } from 'next/navigation';
import { useEffect } from 'react';

export default function ClassworkPage() {
  const { user } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (!user || user.role !== 'teacher') {
      router.push('/login');
    }
  }, [user, router]);

  if (!user || user.role !== 'teacher') {
    return null;
  }

  return <ClassworkView />;
}
