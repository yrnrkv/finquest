'use client';

import React, { useEffect, useState } from 'react';
import { useRouter, useParams } from 'next/navigation';
import { useAuth } from '@/lib/auth-context';
import { QuestInterface } from '@/components/quest/QuestInterface';
import { mockModules, mockQuests } from '@/lib/mock-data';

export default function QuestPage() {
  const router = useRouter();
  const params = useParams();
  const { isAuthenticated, user, isLoading } = useAuth();
  const [currentQuestIndex, setCurrentQuestIndex] = useState(0);

  const moduleId = params.moduleId as string;
  const module = mockModules.find((m) => m.id === moduleId);
  const moduleQuests = mockQuests.filter((q) => q.moduleId === moduleId);

  useEffect(() => {
    if (!isLoading && (!isAuthenticated || user?.role !== 'student')) {
      router.push('/login');
    }
  }, [isAuthenticated, user, isLoading, router]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <p className="text-muted-foreground">Loading quest...</p>
        </div>
      </div>
    );
  }

  if (!module) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <p className="text-muted-foreground">Module not found</p>
        </div>
      </div>
    );
  }

  if (moduleQuests.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <p className="text-muted-foreground">No quests available for this module</p>
        </div>
      </div>
    );
  }

  const currentQuest = moduleQuests[currentQuestIndex];

  const handleQuestComplete = () => {
    if (currentQuestIndex < moduleQuests.length - 1) {
      setCurrentQuestIndex(currentQuestIndex + 1);
    } else {
      router.push('/dashboard');
    }
  };

  return (
    <QuestInterface
      quest={currentQuest}
      module={module}
      questNumber={currentQuestIndex + 1}
      totalQuests={moduleQuests.length}
      onComplete={handleQuestComplete}
    />
  );
}
